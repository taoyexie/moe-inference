# KITE 真实模型实验

本目录用于补充 KITE 技术交底书的实测证据。主线是 Qwen3-30B-A3B 的
真实推理访问记录、Expert/KV 四条恢复路径的实测，以及相同输入条件下的
分配策略对照。以一台 A100 40GB 服务器为实验设备，先完成小规模、可复核的结果。

执行顺序、产物、验收条件和当前缺口见 [工作计划](docs/WORK_PLAN.md)。

## 当前状态

- **最新文书改为 WiSP 对照待测版**：[文档](reports/KITE专利技术交底书_WiSP对照待测版.docx)。按用户要求，将拟用 baseline 改为 WiSP 式 Expert/KV 两类固定 miss 代价的历史分配；原图和全部数值不变，明确标注为原四路径固定成本对照的结果，不能当作 WiSP 测量。WiSP 式对照尚未重跑，之后统一替换图表与技术效果。17 页已逐页检查，旧版本保留；本次未修改实验执行代码或新增 GPU 测试。

- **专利交底书终稿已完成**：[最新终稿（补充 baseline 说明）](reports/KITE专利技术交底书_终稿_baseline说明版.docx)。全文统一使用 baseline，补充四条路径各自的固定成本、历史分配、不加入当前 P/D 修正、共同执行条件及非原始 WiSP 复现的说明。按用户最终选择采用第一版三张零起点柱状图，图和数值不变，保留原系统图和流程图；17 页已逐页渲染检查。此前终稿及原待补实验数据稿均保留；联系人信息保留空栏。不追加 GPU 实验或确认会话。

- **前两张已改为局部纵轴配对点图**：按用户要求突出差异，E2E 纵轴 74–84 s、TPOT 纵轴 1.36–1.58 s，标原始数值和准确耗时下降百分比；不使用截断柱高表达比例。第三张 KV restore 图不变。见 [新版图与口径](reports/kite_parallel_decode_20261016/figures_zoom/README.md) 和 [新版下载](reports/kite_parallel_decode_20261016/kite_experiment_figures_zoom_20261016.zip)。原版和数据均保留。

- **三张实验图已交付**：用户决定不追加三个确认会话。使用已核验的 6/7 GiB 配对结果完成完整 E2E、TPOT、实际 KV restore 三张独立图，PNG 400 dpi 和 SVG 均提供，见 [图与说明](reports/kite_parallel_decode_20261016/figures/README.md) 和 [打包下载](reports/kite_parallel_decode_20261016/kite_experiment_figures_20261016.zip)。数据口径及单次测量说明在配套文件中，不把探索说成独立复测均值；下面的确认计划仅为历史安排。没有新增 GPU 实验。

- **并行场景已实测核验，冻结 6 GiB**：两个预算的原始时钟、路由、真实配额和 892 次资源采样核验通过。[完整发现](reports/kite_parallel_decode_20261016/search_findings.md)：6 GiB 为 82.174 → 75.348 s（1.091×），主执行 51.646 → 48.006 s，KV restore 4934 → 200；真实 decode 配额 256 → 384 页，Expert 两组 GPU hits 都为零。7 GiB 反向顺序也为正，结果全部保留。已冻结原包和配置，下一步仅运行 [留出提示独立确认](docs/KITE_PARALLEL_CONFIRMATION.md)，不继续扫参；确认尚未执行。

- **下一轮包已准备，尚待 GPU 实测**：[四请求并行 decode 容量窗口](docs/KITE_PARALLEL_DECODE.md)。已有两个真实访问来源的条件性 LRU 容量筛查支持 6/7 GiB，而非继续放大缓存：固定半池历史提案时，参考 KV miss 减少且 Expert miss 不增加。这不是新场景实测。新包仅改变到达/预算：四请求同时进入、各 16 输出，去掉单请求空档；固定两预算、每个基线/KITE 各一次，加载一次。启动标定、全部 prefill/decode 和调整均计时；不改算法、不追加精度或消融。确认选择同时检查整体、主执行和实际 KV restore，避免只选启动波动。

- **最新下载核验**：短提示突发两场已完成，见 [诊断](reports/kite_burst_search_20261016/scene_diagnosis.md) 和 [实测表](reports/kite_burst_search_20261016/seed17_audit/report.md)。32 GiB 整体 1.068×，但主执行只快约 0.89%，约 95% 的时间差位于初始化/启动区间；28 GiB 整体慢约 1.58%。两组真实分配全程相同、均约 90% Expert，预期容量窗口未出现。停止重复此方向；下一候选优先筛查多请求长上下文 decode，保留完整 E2E 计时，不把局部区间收益当成整体结果。以下旧“待测/待下载”条目为阶段记录，以本条及相应审计为准。

- **继续找更大整体收益**：8 GiB v3 已通过完整结果审计，主执行只省 1.486 秒；四请求 decode 省约 6.32 秒，单请求 decode 多花约 5.48 秒，抵消大部分收益。下一步只改变场景/预算，采用 [重复短提示突发](docs/KITE_BURST_SEARCH.md)：先 32 GiB，再视预定停止规则最多试 28 GiB；同一完整 KITE 和基线，不改算法、不追加精度/消融。选择依据是已有 20-token 真实 trace 的 2565 专家工作集可能落在两组容量之间，尚无新场景 GPU 数据。见 [数据诊断](reports/kite_performance_v3_20261016/scene_diagnosis.md)。

- **v3 首个正探索结果（待下载核验）**：用户完成 8 GiB 两组主工作负载，终端 E2E 为 baseline 204.423 s、完整 KITE 200.604 s，含启动标定，暂算 1.019× / 耗时下降 1.87%。这是单次受控场景，不是已确认的稳定平均收益。下一步仅下载原始结果，核对计时/资源/输出量和启动贡献，然后进行必要的整体确认并补充专利实施例；不恢复精度探针或消融。见 [终端记录](reports/kite_performance_v3_20261016/first_positive_console.md)。

- **当前唯一主线（用户最新指示）**：停止新增精度探针和模块消融，直接运行完整 KITE 对固定成本基线的真实端到端场景。使用独立 `kite-advantage-20261016-v3.zip`，步骤见 [直接性能运行指南](docs/KITE_PERFORMANCE_RUN.md)。不再执行跨形态 logits 精度门禁；保留成本标定、有限值/拷贝完整性检查、缓存预算与 GPU 干扰保护。原 BF16 执行、8 GiB 场景与分配参数不变，不把未做的质量验证标为通过。141 项本机控制流/逻辑回归通过，尚待 v3 GPU 实测；最终文书只填实际得到的整体收益与适用条件，不声称无精度损失。

- **当前主线**：完整 KITE v2 已在 A100 完成三预算、两组的真实端到端运行并通过原始记录审计；原 replay 检查不再失败，但 KITE 在 512/1024/2048 MiB 分别慢 15.98%/16.99%/23.96%，尚无整体净收益。见 [实测核验](reports/kite_e2e_20261016_v2_seed17_audit/report.md) 和 [负收益诊断](reports/kite_e2e_20261016_v2_seed17_diagnosis/report.md)：CPU 热标定/冷执行不匹配，Expert 曲线在当前预算内平坦，KV 压力有限。执行器和实验参数未因结果而修改，下一步先修成本语义，再确认新的受控场景。

- **继续探索**：用户已授权继续寻找优势场景。[第二轮运行指南](docs/KITE_ADVANTAGE_GUIDE.md) 对应 `kite_advantage.py`：只测 8 GiB 两组各一次，三次长上下文突发，KV 峰值约 3.89 GiB。v1 已通过服务器小型高效注意力检查并完成加载，但资源监控启动失败，尚无正式长场景测量。保留四路径、历史曲线及 .65 P/D 融合，不强制基线选择不利分配；新旧版本结果不得混比。

- **本次就绪复核**：准备独立 `kite-advantage-20261016-v2` 包，新增不使用 CUDA 的 `check`、提前资源监控与详细 PID 证据，修复稳健拟合前置顺序和临时 KV 工作区延迟释放；129 项本机回归通过。场景与算法参数不变，见 [复核与待验项目](docs/KITE_READY_TO_RUN.md)。仍须空闲 A100 验证新版数值检查、长上下文峰值和真实端到端效果，不能承诺胜出。

- **新版 GPU 门禁结果**：用户已运行上述 v2；资源检查和模型加载成功，短 packed/serial 的 `upload,restore` 检查失败，relative L2=0.048166 超过 .03，正式标定及测量未开始。不能称作已修复或性能负结果。已准备独立 [短数值诊断包](docs/KITE_NUMERICAL_DIAGNOSIS.md)，逐层区分默认注意力、显式 mask、增量缓存、分页恢复与混合批次误差；正式源码、参数和阈值不变。133 项本机回归通过，诊断本身仍需空闲 GPU 执行。

- **短诊断终端更新**：用户已完成诊断，逐请求 packed 全前缀与原生全前缀完全一致；原生增量与分页增量的汇总 L2 均为 .031335，混合为 .048165。完整 JSON 尚待下载，不能只凭相同汇总误差证明张量一致或宣称根因已确定。见 [终端发现与待核对项](reports/kite_numerics_20261016_preparation/server_console_findings.md)。先分析现有记录，不追加 GPU 重跑。

- **下载复核更新**：五个 JSON 已核对，605 次资源采样无干扰；原生/分页增量的全部 772 项阶段误差及 96 项路由比较记录一致。混合 decode 在第一层实际 Q/K/V 和 SDPA 原始输出仍对参考完全一致，额外差异在 o_proj 环节出现，此后路由改变；五种变体的两个 next-token argmax 相同，但不代表整段质量保证。见 [详细发现](reports/kite_numerics_20261016_preparation/downloaded_findings.md)。已准备 [仅第一层的轻量投影探针](docs/KITE_PROJECTION_PROBE.md)，不再加载整个 Qwen，先检验数值设置；未修改正式 v2 或阈值。136 项本地测试通过。

- 本机工作目录：`D:\moe inference`。
- 远程项目目录：`/data2/xty/epkv`；容器中对应 `/workspace`。
- 已验证：SSH、Docker GPU 接入、Python 3.12.3、PyTorch 2.7.1+cu118、真实 GPU 矩阵乘法。
- 服务器：A100 40GB，双路 Xeon Gold 5318Y，48 个物理核心 / 96 个逻辑 CPU，125 GiB 主存。
- GPU 拓扑：NUMA 节点 1，对应 CPU 24–47 和 72–95。
- 已完成：ModelScope BF16 checkpoint 下载核验、一次真实 Qwen 推理、专家调用与 KV 元数据采集。
- 2026-10-15 首轮原始日志已离线核验：20 输入 tokens、8 输出 tokens，5,253 个非空专家调用，384 个层×forward 路由计数通过。
- 尚未完成：多请求真实 trace、分配效果测量；专家调用不等于物理 cache miss。
- 已准备：Qwen 短请求采集脚本、资源门禁、模型下载入口、轻量测试与操作说明。
- 三个专家的两路径微基准已在服务器完成 3 个正式进程会话，共 10,800 条计时记录，见 [专家路径指南](docs/EXPERT_PATHS_GUIDE.md)。
- 常数/线性成本的探索性结果与图见 [专家成本模型报告](reports/expert_cost_models_20261015/report.md)。含选取的低 q 标定优势示例及全范围拟合无收益结果，不是 KITE 端到端评测。
- KV restore/recompute 两长度小试跑已在服务器执行，下载文件核验通过；固定 128-token 全层 KV 块，共 12 条正式计时、4 条预热，远端记录的所有数值误差为 0。见 [核验报告](reports/kv_paths_pilot_20261015_audit/report.md) 与 [KV 路径指南](docs/KV_PATHS_GUIDE.md)。尚未完成更多长度扫描或验证线性，重算含权重卸载传输，且不能按每块重复计费。
- 更新：五长度 KV 扫描及预定标定/验证已完成，见 [成本拟合](reports/kv_cost_models_20261015/report.md)。50 条正式计时、20 条预热全部核验；restore 验证 MAPE 约 0.17%，重算约 11.60%，负斜率保留且禁止外推。该条更新上一条的扫描状态。
- 已确认：不新增每层 hidden-state 缓存；KV 从原始 token 重放，按实际重放任务计费，共享块与内部 Expert 恢复不重复收费。下一项准备多请求 trace 与明确计费语义的重放对照，尚未实现/运行联合分配器。
- 多请求采集入口已准备，见 [采集说明](docs/MULTI_TRACE_GUIDE.md)：一次加载、6 条受控顺序请求，128/512/1024 输入 tokens 各两条、每条最多输出 8 tokens。尚未远程执行；它扩大已有真实 trace，不替换或否认旧单请求实测。
- 工作负载级决策核心已实现并有本机测试，见 [运行框架状态](docs/KITE_RUNTIME_STATUS.md)。新 E2E 原型已接实际标定和物理执行；原独立决策接口仍不声称改变 GPU 缓存。GPU 联合功能尚待首次验证。
- 现有后端的无专家采集 hooks 性能试跑已于 2026-10-16 完成并核验，见 [核验报告](reports/workload_baseline_20261016_audit/report.md)。五条评价请求平均 TTFT 9.834 秒、TPOT 9.293 秒、完成时间 74.886 秒；模型加载与 warmup 原样留档。不是 KITE/WISP 对照。
- 独立 Expert 物理缓存于 2026-10-16 在服务器验收通过，见 [核验报告](reports/expert_cache_20261016_audit/report.md)。60 次调用、48 次启动计时全部通过数值检查，离线状态重放一致。尚未接回完整模型，受控调用顺序不宣称自然 trace 或端到端加速。
- [专家成本选择配对测量](docs/EXPERT_CACHE_BENCH_GUIDE.md) seed17 首轮已完成并核验，见 [报告](reports/expert_cache_bench_20261016_seed17_audit/report.md)。两个主动选择的压力场景，平均配对执行耗时分别下降 45.57%/29.54%；稳定热点基本持平。每场景 10 组配对，非完整模型、KITE 或 WiSP 评测；启动和初始化开销单列，待独立进程复测。

首次操作步骤见 [Qwen 短请求指南](docs/QWEN_SMOKE_GUIDE.md)。

新版 v2 支持 `prepare --source modelscope`，官方 ModelScope 分支/标签与文件 SHA256
共同留档，不将其冒充为 Hugging Face commit。原 HF 入口仍保留。

v3 修复首次加载前 CUDA 统计初始化顺序，增加 `cuda-check` 微检查；沿用已下载的权重。

## 文件使用原则

代码和计划在本目录编写；GPU 执行发生在远程容器。本机不需要安装 CUDA。
每条面向用户的命令都说明执行位置、作用、关键参数、修改范围和预期输出。
运行信息、原始样本、模型 revision、输入 token IDs 与参数必须留档。
实验提升只依据完成的测量填写，真实测量、逻辑访问推导和 trace 重放分别标识。
SSH 私钥、密码和访问 token 不存入本项目，也不提交到 Git。

## 既有材料

- 设计依据：`D:\working\epkv\beamer\ppt.pdf`，KITE 的联合分配设计。
- 交底书格式参考：`D:\working\一种基于层级敏感性的 KV 复用与重计算组合优化求解方法.docx`，属于另一技术，不能移用其结果。
- 原工作区：`C:\Users\eyess\Documents\Codex\2026-10-13\gpu-gpu`。
  其中 `expert_paths_bench.py` 使用随机权重，`kite_real_trace.py` 只适配 OLMoE；
  二者不能直接作为 Qwen 实测工具使用。本次未移动、删除或覆盖原文件。
