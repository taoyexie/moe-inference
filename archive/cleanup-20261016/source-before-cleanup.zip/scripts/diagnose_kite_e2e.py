"""Read-only E2E evidence diagnosis; no model loading or estimated speedup claims.

Reconstructs Expert dispatch and both LRU states from recorded actual accesses.
Reconstruction must match every batch counter. Reference MRC is separate from
the real bypass cache and is not a prediction of timings under another budget.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import Counter, OrderedDict
from pathlib import Path
from statistics import mean, median

from audit_kite_e2e import audit, read, require
from kite_controller import ReuseStack, miss_count
from kite_e2e_core import EXPERT_BYTES, KV_BYTES


def predicted_cpu(calibration, mode, q):
    lo,hi = calibration['domains']['expert_cpu']
    if not lo<=q<=hi:
        return math.inf
    if mode=='baseline':
        return calibration['fixed']['expert_cpu']
    fit = calibration['affine']
    value = fit['expert_cpu_intercept_ms']+fit['expert_cpu_slope_ms']*q
    return value if math.isfinite(value) and value>=0 else math.inf


def reconstruct_experts(batches, calibration, mode, cpu_limit_bytes):
    """Exact counter reconstruction for this run's no-formal-replay workloads."""
    require(calibration['cpu_fp32_cache_bytes']==2*EXPERT_BYTES,
            'Expected the one captured expert to be the sole startup FP32 copy.')
    gpu = OrderedDict()
    cpu = OrderedDict([(tuple(calibration['capture']['key']),None)])
    cpu_capacity = cpu_limit_bytes//(2*EXPERT_BYTES)
    require(cpu_capacity>=1,'CPU FP32 cache cannot hold its startup expert.')
    total,by_phase = Counter(),{}
    for row in batches:
        quota = row['decision']['candidate']['expert_objects']
        while len(gpu)>quota:
            gpu.popitem(last=False)
        phase = 'mixed' if row['prefill'] and row['decode'] else ('prefill' if row['prefill'] else 'decode')
        subtotal = by_phase.setdefault(phase,Counter())
        for key,q in row['expert_accesses']:
            key = tuple(key)
            total['expert_calls'] += 1
            subtotal['calls'] += 1
            if key in gpu:
                gpu.move_to_end(key)
                total['expert_hits'] += 1
                subtotal['gpu_hits'] += 1
                continue
            total['expert_misses'] += 1
            if predicted_cpu(calibration,mode,q)<calibration['fixed']['expert_upload']:
                total['expert_cpu'] += 1
                subtotal['cpu'] += 1
                if key in cpu:
                    cpu.move_to_end(key)
                    total['cpu_fp32_cache_hits'] += 1
                    subtotal['cpu_warm'] += 1
                else:
                    total['cpu_fp32_conversions'] += 1
                    subtotal['cpu_cold'] += 1
                    if len(cpu)==cpu_capacity:
                        cpu.popitem(last=False)
                        total['cpu_fp32_evictions'] += 1
                    cpu[key] = None
            else:
                total['expert_upload'] += 1
                subtotal['upload'] += 1
                if len(gpu)==quota:
                    gpu.popitem(last=False)
                gpu[key] = None
        require(total==Counter(row['expert_counts']),
                f'Expert dispatch/cold-conversion reconstruction differs at batch {row["step"]}.')
    return dict(counters=dict(total),by_phase={k:dict(v) for k,v in by_phase.items()},
                all_batch_counters_match=True,cpu_fp32_capacity_experts=cpu_capacity)


def expert_reference(batches):
    stack,histogram = ReuseStack(),Counter()
    for row in batches:
        for key,_ in row['expert_accesses']:
            histogram[stack.access(tuple(key))] += 1
    finite = [d for d in histogram if d is not None]
    capacities = (14,28,56,113,170,204,227,384,455,614,819,1024)
    total = sum(histogram.values())
    minimum = min(finite) if finite else None
    return dict(scope='offline empty-start fixed-capacity admit-on-access LRU reference of actual main-run accesses; not actual CPU-bypass cache or future timings',
                calls=total,unique_experts=len(stack.last),minimum_finite_reuse_distance=minimum,
                first_possible_hit_capacity=minimum+1 if minimum is not None else None,
                histogram=[dict(reuse_distance=d,count=n) for d,n in sorted(histogram.items(),key=lambda x:-1 if x[0] is None else x[0])],
                points=[dict(capacity_experts=cap,expert_bytes=cap*EXPERT_BYTES,
                             hits=total-miss_count(histogram,cap),misses=miss_count(histogram,cap))
                        for cap in capacities])


def diagnose_task(folder, cpu_limit):
    perf,calibration = read(folder/'performance.json'),read(folder/'calibration.json')
    batches = [json.loads(line) for line in (folder/'batches.jsonl').read_text(encoding='utf-8').splitlines()]
    recoveries = read(folder/'recoveries.json')
    require(not perf['kv_counts'].get('kv_replay_tasks',0),'This dispatch reconstruction excludes formal replay children.')
    reconstruction = reconstruct_experts(batches,calibration,perf['mode'],cpu_limit)
    cpu = perf['expert_counts'].get('expert_cpu',0)
    cold = perf['expert_counts'].get('cpu_fp32_conversions',0)
    uploads = [r['wall_ms'] for r in calibration['rows'] if r['path']=='expert_upload' and not r['warmup']]
    q1warmup = [r['wall_ms'] for r in calibration['rows'] if r['path']=='expert_cpu' and r['x']==1 and r['warmup']]
    q1formal = [r['wall_ms'] for r in calibration['rows'] if r['path']=='expert_cpu' and r['x']==1 and not r['warmup']]
    quotas = Counter((r['decision']['candidate']['expert_objects'],r['decision']['candidate']['kv_objects']) for r in batches)
    return dict(budget_mib=perf['budget_mib'],mode=perf['mode'],
        workload_total_ms=perf['workload_total_ms'],startup_ms=perf['startup_inclusive_ms'],execution_ms=perf['execution_inclusive_ms'],
        expert_counts=perf['expert_counts'],kv_counts=perf['kv_counts'],
        cpu_cold_fraction=cold/cpu if cpu else None,
        cpu_conversion_output_bytes=cold*2*EXPERT_BYTES,
        host_kv_peak_bytes=perf['host_kv_peak_bytes'],
        explicit_resize_ms=sum(r['resize_ms'] for r in batches),
        actual_recovery_wall_ms=sum(r['wall_ms'] for r in recoveries),
        cost_fixed=calibration['fixed'],cost_affine=calibration['affine'],
        startup_upload_samples_ms=uploads,startup_upload_mean_ms=mean(uploads),startup_upload_median_ms=median(uploads),
        startup_cpu_q1_warmup_ms=q1warmup,startup_cpu_q1_formal_mean_ms=mean(q1formal),
        quotas=[dict(expert_objects=e,kv_objects=k,batches=n) for (e,k),n in quotas.items()],
        reconstruction=reconstruction,expert_lru_reference=expert_reference(batches))


def report(result):
    lines = ['# KITE v2 首次完整运行：负收益原因核查','',
        '数据来自下载的完整原始记录，先通过端到端审计，再逐批重放 Expert 路径选择、GPU LRU 和 CPU FP32 LRU。'
        '不修改执行器、参数或原始数据，不运行模型，不将离线曲线当成实测加速。','',
        '## 实测结果','',
        '| 预算 MiB | 基线 E2E s | KITE E2E s | 加速比 | 基线推理段 s | KITE 推理段 s |',
        '|---|---:|---:|---:|---:|---:|']
    tasks = {(r['budget_mib'],r['mode']):r for r in result['tasks']}
    for pair in result['audit']['comparisons']:
        b = pair['budget_mib']
        base,kite = tasks[b,'baseline'],tasks[b,'kite']
        lines.append(f'| {b} | {base["workload_total_ms"]/1000:.3f} | {kite["workload_total_ms"]/1000:.3f} | '
                     f'{pair["speedup"]:.3f}× | {base["execution_ms"]/1000:.3f} | {kite["execution_ms"]/1000:.3f} |')
    lines += ['', '## 1. CPU 路径的预热标定与真实冷状态不一致','',
        '启动阶段用同一专家 q=1/8/32 重复测量：第一次 CPU 调用处于 warmup、含 FP32 冷转换，未参与拟合；'
        '随后的正式样本均复用该 FP32 副本。实际执行器却不检查该副本是否存在，就用同一条仿射模型选 CPU。'
        '这不是线性函数形状本身的问题，而是标定条件与调用条件不匹配。','',
        '| 预算 MiB | KITE CPU 调用 | 冷转换次数 | 冷比例 | CPU FP32 淘汰次数 |',
        '|---|---:|---:|---:|---:|']
    for budget in (512,1024,2048):
        row = tasks[budget,'kite']
        c = row['expert_counts']
        lines.append(f'| {budget} | {c["expert_cpu"]} | {c["cpu_fp32_conversions"]} | '
                     f'{100*row["cpu_cold_fraction"]:.2f}% | {c["cpu_fp32_evictions"]} |')
    lines += ['', '8 GiB 只能放下 455 个 FP32 Expert。逐批离线状态重放与全部实际计数完全一致，'
        '说明大量冷转换不是从总耗时猜出来的。不过原日志没有逐调用耗时分解，不能把额外 10–16 秒全部量化归因于转换。'
        '首次 CPU warmup 还包含首次算子预热，不能把其与正式样本之差直接作为纯转换耗时。','',
        '修正方向：保持四路径和常数/仿射形式，区分 CPU 副本存在与否；将单独测得的固定冷转换项计入路径决策，'
        '两组共用相同冷状态处理。该建议尚未实施或测得收益，不能通过预热全部副本或移出计时隐藏成本。','',
        '## 2. 当前预算处在 Expert miss curve 的完全平坦段','',
        '对基线真实访问序列从空缓存计算，最小有限复用距离为 380 个 Expert，LRU 容量至少 381 个才可能出现首次命中。'
        '每专家 9 MiB，约需 3429 MiB 的专家容量；整个 2 GiB 预算即使全给专家也只能放 227 个。'
        '因此三个预算都不足以让该全局 admit-on-access LRU 专家曲线出现下降；三个基线实际 Expert hit 都为 0。','',
        'KITE 实际仍有 163/253/540 个 GPU hit，因为 CPU bypass 不准入可保留部分已上传专家；'
        '这不与平坦 reference 曲线矛盾，也不能把 reference 命中数冒称实际缓存命中数。','',
        '若要继续研究容量分配收益，应先用真实曲线找出有效容量区间，同时重新设计 KV 压力；'
        '不能盲目扩大预算后宣称必有收益。新范围属于新的探索协议，旧负结果保留，不复用旧选择文件。','',
        '## 3. 当前 KV 工作集很小，未形成两类资源的有效竞争','',
        '| 预算 MiB | 基线 KV miss | KITE KV miss | 基线实际恢复累计 ms | KITE 实际恢复累计 ms |',
        '|---|---:|---:|---:|---:|']
    for budget in (512,1024,2048):
        base,kite = tasks[budget,'baseline'],tasks[budget,'kite']
        lines.append(f'| {budget} | {base["kv_counts"].get("kv_misses",0)} | {kite["kv_counts"].get("kv_misses",0)} | '
                     f'{base["actual_recovery_wall_ms"]:.3f} | {kite["actual_recovery_wall_ms"]:.3f} |')
    lines += ['', '主阶段 KV CPU 副本峰值为 384 MiB，即 32 个页；1/2 GiB 下两组的 832 次 KV 读取全部命中。'
        '512 MiB 时 KITE 确实减少 166 次 KV miss，但两次运行中记录的恢复宏操作累计只相差约 95.3 ms，'
        '远小于 10.6 s 的 E2E 差距；这不是其他配置的反事实加速估计。正式阶段没有任何 KV replay。','',
        'decode 阶段 KITE 的 KV 配额在 1 GiB 为 64 页、2 GiB 为 128 页，明显高于该任务的 32 页峰值；'
        '无条件 P/D 比例修正在这两个配置中未进一步减少 KV miss。这里只能判断此工作负载未发挥该机制优势，'
        '不能据此证明 phase-aware 普遍无效，也不能证明缩小该配额必然更快，因为当前 Expert reference 曲线本身平坦。','',
        '显式 resize 函数累计仅约 1.3–1.6 ms；它不包括淘汰后的后续恢复，不能代表全部调整代价。','',
        '## 4. 启动常数样本受单个长尾值影响','',
        '2 GiB KITE 的九个 upload 正式样本中有一个 15.313240 ms，其余均小于 0.7 ms；'
        '均值 2.300630 ms，中位数 0.674113 ms。代码按预定均值将该值保留，导致 q=1..32 全域均判 CPU 更便宜。'
        '1 GiB KITE 的 upload 均值为 0.642982 ms，CPU 只在 q≤11 时更便宜。'
        '这是路径选择扩大的一项直接数值原因，但没有足够信息判断长尾值来自何种系统事件，不能随意删除原始样本。','',
        '后续若改用更稳健的常数估计，必须预先定义规则、对两组统一执行，并保留全部原始样本。','',
        '## 结论与边界','',
        '本次是完整模型、真实混合批次和真实缓存的端到端负结果，不是微基准，也不是原始 WiSP。'
        '已确认实现存在热标定/冷执行的成本语义不匹配，预算又没有覆盖 Expert 曲线有效区间，'
        'KV 压力仅在最小预算略有体现。下一步应先修成本语义，再明确新的受控场景，不无限扫参。','',
        '1 GiB 两组生成 token 完全相同，仍慢约 17%，说明负结果并非只能由生成序列差异解释；'
        '512 MiB/2 GiB 的生成序列不同，固定输出长度相同，但路由工作量略不同，已在原审计中披露。'
        '没有正式质量测评或逐调用时间分解，不能夸大数值验证或因果归因。','']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    audited = audit(args.run)
    root = read(args.run/'summary.json')
    tasks = [diagnose_task(args.run/f'{row["budget_mib"]}-{row["mode"]}',
                          root['protocol']['cpu_fp32_cache_gib']*1024**3)
             for row in root['tasks']]
    result = dict(audit=audited,tasks=tasks,scope='read-only offline diagnosis; no new GPU execution or cost-synthesized speedup')
    require(not args.output.exists(),'Refusing to overwrite a diagnosis.')
    args.output.mkdir(parents=True)
    (args.output/'diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (args.output/'report.md').write_text(report(result),encoding='utf-8')
    print(json.dumps(dict(status='passed',report=str(args.output/'report.md')),ensure_ascii=False))


if __name__=='__main__':
    main()
