"""Immutable allowlisted source bundle; never includes model weights or credentials."""
from hashlib import sha256
import json
from zipfile import ZipFile,ZIP_DEFLATED
from package_kite_advantage import FILES,ROOT

NAME = 'kite-parallel-decode-20261016-v1'
EXTRA = ['scripts/kite_parallel_decode.py','scripts/audit_kite_parallel_decode.py',
    'scripts/screen_kite_parallel_decode.py','tests/test_kite_parallel_decode.py',
    'tests/test_kite_parallel_decode_driver.py','docs/KITE_PARALLEL_DECODE.md']


def main():
    target = ROOT/'dist'/(NAME+'.zip')
    target.parent.mkdir(parents=True,exist_ok=True)
    manifest = dict(name=NAME,files=[])
    with ZipFile(target,'x',ZIP_DEFLATED) as archive:
        for filename in FILES+EXTRA:
            data = (ROOT/filename).read_bytes()
            archive.writestr(NAME+'/'+filename,data)
            manifest['files'].append(dict(path=filename,bytes=len(data),sha256=sha256(data).hexdigest()))
        archive.writestr(NAME+'/bundle_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps(dict(zip=str(target),bytes=target.stat().st_size,sha256=sha256(target.read_bytes()).hexdigest()),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
